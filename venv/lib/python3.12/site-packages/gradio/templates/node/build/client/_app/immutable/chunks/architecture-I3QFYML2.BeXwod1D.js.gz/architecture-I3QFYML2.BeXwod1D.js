import { A, e } from "./mermaid-parser.core.CG78kFdv.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
