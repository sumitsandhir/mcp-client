import { G, f } from "./mermaid-parser.core.CG78kFdv.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
