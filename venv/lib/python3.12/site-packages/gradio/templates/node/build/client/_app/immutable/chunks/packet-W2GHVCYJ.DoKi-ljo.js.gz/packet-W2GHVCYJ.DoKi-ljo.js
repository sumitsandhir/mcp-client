import { P, a } from "./mermaid-parser.core.CG78kFdv.js";
export {
  P as PacketModule,
  a as createPacketServices
};
