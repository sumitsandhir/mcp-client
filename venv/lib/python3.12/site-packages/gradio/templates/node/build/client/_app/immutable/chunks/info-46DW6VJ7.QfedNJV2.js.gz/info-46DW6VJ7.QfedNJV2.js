import { I, c } from "./mermaid-parser.core.CG78kFdv.js";
export {
  I as InfoModule,
  c as createInfoServices
};
